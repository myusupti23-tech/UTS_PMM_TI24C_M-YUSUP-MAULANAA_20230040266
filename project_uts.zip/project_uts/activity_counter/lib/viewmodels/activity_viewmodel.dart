import 'package:flutter/foundation.dart';
import '../models/activity_model.dart';
import '../repositories/activity_repository.dart';

class ActivityViewModel extends ChangeNotifier {
  final ActivityRepository _repository = ActivityRepository();

  List<ActivityModel> get activities => _repository.getActivities();

  void addActivity(String name) {
    String newId = DateTime.now().millisecondsSinceEpoch.toString();
    ActivityModel newActivity = ActivityModel(id: newId, name: name, counter: 0);
    _repository.addActivity(newActivity);
    notifyListeners();
  }

  void updateActivityName(String id, String newName) {
    var activity = activities.firstWhere((a) => a.id == id);
    activity.name = newName;
    _repository.updateActivity(activity);
    notifyListeners();
  }

  void incrementCounter(String id) {
    var activity = activities.firstWhere((a) => a.id == id);
    activity.counter++;
    _repository.updateActivity(activity);
    notifyListeners();
  }

  void decrementCounter(String id) {
    var activity = activities.firstWhere((a) => a.id == id);
    if (activity.counter > 0) {
      activity.counter--;
      _repository.updateActivity(activity);
      notifyListeners();
    }
  }

  void resetCounter(String id) {
    var activity = activities.firstWhere((a) => a.id == id);
    activity.counter = 0;
    _repository.updateActivity(activity);
    notifyListeners();
  }

  void deleteActivity(String id) {
    _repository.deleteActivity(id);
    notifyListeners();
  }
}