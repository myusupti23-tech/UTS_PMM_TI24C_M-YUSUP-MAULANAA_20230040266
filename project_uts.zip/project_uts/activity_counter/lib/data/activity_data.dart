import '../models/activity_model.dart';

class ActivityData {
  // Penyimpanan data sementara menggunakan List
  List<ActivityModel> activities = [
    ActivityModel(id: '1', name: 'Membaca Buku Pemrograman', counter: 3),
    ActivityModel(id: '2', name: 'Push-up Harian', counter: 15),
    ActivityModel(id: '3', name: 'Menyelesaikan Modul Kuliah', counter: 1),
  ];
}