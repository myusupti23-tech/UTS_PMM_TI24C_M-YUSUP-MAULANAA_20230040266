import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../viewmodels/activity_viewmodel.dart';

class ActivityDetailView extends StatelessWidget {
  final String activityId;

  const ActivityDetailView({super.key, required this.activityId});

  @override
  Widget build(BuildContext context) {
    return Consumer<ActivityViewModel>(
      builder: (context, viewModel, child) {
        var activityList = viewModel.activities.where((a) => a.id == activityId);
        if (activityList.isEmpty) {
          return Scaffold(
            appBar: AppBar(title: const Text('Detail Aktivitas')),
            body: const Center(child: Text('Aktivitas tidak ditemukan atau telah dihapus.')),
          );
        }
        final activity = activityList.first;

        return Scaffold(
          appBar: AppBar(
            title: Text(activity.name),
            backgroundColor: Colors.indigo,
            foregroundColor: Colors.white,
          ),
          body: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  activity.name,
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 30),
                const Text(
                  'Nilai Penghitung (Counter):',
                  style: TextStyle(fontSize: 16, color: Colors.grey),
                ),
                Text(
                  '${activity.counter}',
                  style: const TextStyle(fontSize: 72, fontWeight: FontWeight.bold, color: Colors.indigo),
                ),
                const SizedBox(height: 30),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    FloatingActionButton(
                      heroTag: 'decrement',
                      backgroundColor: Colors.redAccent,
                      foregroundColor: Colors.white,
                      onPressed: () {
                        if (activity.counter > 0) {
                          viewModel.decrementCounter(activity.id);
                          _showFeedback(context, 'Counter dikurangi');
                        } else {
                          _showFeedback(context, 'Nilai counter tidak boleh kurang dari 0');
                        }
                      },
                      child: const Icon(Icons.remove),
                    ),
                    const SizedBox(width: 30),
                    FloatingActionButton(
                      heroTag: 'increment',
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      onPressed: () {
                        viewModel.incrementCounter(activity.id);
                        _showFeedback(context, 'Counter ditambah');
                      },
                      child: const Icon(Icons.add),
                    ),
                  ],
                ),
                const SizedBox(height: 40),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                  ),
                  icon: const Icon(Icons.refresh),
                  label: const Text('Reset Counter'),
                  onPressed: () {
                    _showResetConfirmation(context, viewModel, activity.id);
                  },
                ),
                const SizedBox(height: 15),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                  ),
                  icon: const Icon(Icons.delete),
                  label: const Text('Hapus Aktivitas'),
                  onPressed: () {
                    _showDeleteConfirmation(context, viewModel, activity.id, activity.name);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showFeedback(BuildContext context, String message) {
    ScaffoldMessenger.of(context).removeCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(milliseconds: 800)),
    );
  }

  void _showResetConfirmation(BuildContext context, ActivityViewModel viewModel, String id) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Konfirmasi Reset'),
        content: const Text('Apakah Anda yakin ingin mereset nilai counter menjadi 0?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, foregroundColor: Colors.white),
            onPressed: () {
              viewModel.resetCounter(id);
              Navigator.pop(context);
              _showFeedback(context, 'Counter berhasil di-reset');
            },
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmation(BuildContext context, ActivityViewModel viewModel, String id, String name) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Aktivitas'),
        content: Text('Apakah Anda yakin ingin menghapus "$name"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: () {
              viewModel.deleteActivity(id);
              Navigator.pop(context); 
              Navigator.pop(context); 
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Aktivitas berhasil dihapus')),
              );
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }
}