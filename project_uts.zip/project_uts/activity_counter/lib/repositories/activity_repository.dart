import '../data/activity_data.dart';
import '../models/activity_model.dart';

class ActivityRepository {
  final ActivityData _activityData = ActivityData();

  List<ActivityModel> getActivities() {
    return _activityData.activities;
  }

  void addActivity(ActivityModel activity) {
    _activityData.activities.add(activity);
  }

  void updateActivity(ActivityModel updatedActivity) {
    int index = _activityData.activities.indexWhere((a) => a.id == updatedActivity.id);
    if (index != -1) {
      _activityData.activities[index] = updatedActivity;
    }
  }

  void deleteActivity(String id) {
    _activityData.activities.removeWhere((a) => a.id == id);
  }
}